Membres du groupe:
	ABBAD Kamel 21911536
	BOUSADIA Lahcene 21911132
	HASNAOUI Yahya 21912359
	DIMITRI Stepaniak 21709178

Numéro du groupe: 42

1-Ouvrir le terminal ou les répertoires se trouve.

2-Pour compiler le code, coller la commande suivante: 
	javac -d "build" -cp "sc_jar/scheduleio.jar:." filrouge/*.java

3-Pour executer la classe Main(Test) coller la commande suivante:
	java -cp "build:sc_jar/scheduleio.jar" filrouge.Test


REMARQUE: Le dossier sc_jar contient l'archive de la librairie schelduleio.jar


 


