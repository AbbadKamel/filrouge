package filrouge;
import java.util.HashMap;

public class PrecedenceConstraint extends BinaryConstraint{

		public PrecedenceConstraint(Activity first, Activity second){
		//Constructeur qui initialise les attributs(appelle super)
			super(first,second);
		}

		public boolean isSatisfied(int date1, int date2){
		//Test si act2 commence après act2 avec deux horaires
			if((date1*60 + this.first.duree) <= (date2*60)){
				return true;
			} else{
					return false;
		    }
		}

		public String toString(){
		return "\n*"+this.first+"  commence avant :  " + this.second+" ";
		}

}
