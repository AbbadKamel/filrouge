package filrouge;
import java.util.ArrayList;
import java.util.HashMap;

public class MaxSpanConstraint implements Constraint{

    public ArrayList<Activity> list; //les activités sur lesquelles la contrainte porte
    public int maxSpan; //la durée maximale autorisée (en minutes)

    public MaxSpanConstraint(ArrayList<Activity> list, int maxSpan){
    	//Un constructeur qui initialise les attributs
    	    this.list = list ;
    	    this.maxSpan=maxSpan;

    }

    public boolean isSatisfiedBySchedule(HashMap<Activity, Integer> edt){
 	//Méthode isSatisfiedBySchedule
 		int t0=edt.get(this.list.get(0));//Activité 1
 		int debutf = edt.get(this.list.get(this.list.size()-1)); //Debut Activité 1
 		int dureef = this.list.get(this.list.size()-1).duree; //Durée Activité FIN
 		int tf=debutf+dureef;//Date de la fin
 		int duree=tf-t0;//Durée totale des activités
 		return duree<=this.maxSpan;
	}

    public String toString(){
        return "\nListe d'activitées:"+this.list+" se deroulent dans un span de : "+maxSpan+" min\n";
    }

}
