package filrouge;
import java.util.HashMap;

public abstract class BinaryConstraint implements Constraint{

		Activity first;	//Une premiere activité
		Activity second; //Une deuxieme activité

		public BinaryConstraint(Activity first,Activity second){
		//Un constructeur qui initialise les attributs de la classe
			this.first = first;
			this.second = second;
		}

		//Méthode isSatisfied qui compare entre les deux dates
		abstract boolean isSatisfied(int date1,int date2);

		//Méthode isSatisfiedBySchedule qui prends en arguments un edt
		public boolean isSatisfiedBySchedule(HashMap<Activity, Integer> edt){
				return isSatisfied(edt.get(this.first),edt.get(this.second));
		}

}
