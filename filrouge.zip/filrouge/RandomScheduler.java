package filrouge;
import java.util.Random;
import java.util.Set;
import java.util.List;
import java.util.HashSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.HashMap;
import java.util.Map;

public class RandomScheduler{
	//Les attributs de la classe
    public  Set<Activity> activities;
    public  List<Constraint> constraints;
    public  java.util.Random randomGenerator;

    public RandomScheduler(){
    //Constructeur qui initialise les attributs
        this.activities = new HashSet<Activity>();
        this.constraints = new ArrayList<Constraint>();
        this.randomGenerator = new Random();
    }

    public void addActivity(Activity activite){
    //Ajouter une activité quelconque à l'ensemble
        this.activities.add(activite);
    }

    public void addConstraint(Constraint constraint){
    //Ajouter une contrainte quelconque à l'ensemble
        this.constraints.add(constraint);
    }

    public HashMap<Activity, Integer> createHashMap(){
		
		HashMap<Activity, Integer> schedular = new HashMap<Activity, Integer>();//Un nouveau schedular qui est vide

		for(Activity act:this.activities){//Remplir le scheduler avec toutes les activités dans un temps aléatoire
		
			schedular.put(act,this.randomGenerator.nextInt(24));
		}
		return schedular;
	}	


	public int nbConstraint(HashMap<Activity, Integer> m){//Une méthode qui retourne le nombre de contraintes qu'il satisfait
	
		int c = 0; //Le nombre des contraintes satisfaites
		for( Constraint co:this.constraints){
                if(co.isSatisfiedBySchedule(m)){
                    c++;//Si la contrainte est satisfaite, il s'incrémente
                }
		}
		return c;//Retourner le nombre
	}

	public HashMap<Activity, Integer> scheduleGenerator(int n){//Méthode qui retourne l'emplois qui satisfait le plus de contraintes
	
		HashMap<Activity, Integer> topSchedule = createHashMap();//Initialiser le premier emplois comme le meilleur
		for (int i=1;i<n;i++ ) {//Boucle commence de 1 vu que le 0 est déjà initialisé
			HashMap<Activity, Integer> schedule = createHashMap();//Créer un scheduler aléatoire
			if (nbConstraint(schedule)>nbConstraint(topSchedule)) {//Test si le scheduler satisfait plus de contraintes que celui qu'on a initialisé avant
				topSchedule=schedule;//Affecter pour le topScheduler
			}
		}
		return topSchedule;//Retourner le meilleur Scheduler
	}
}
