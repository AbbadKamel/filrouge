package filrouge;
import java.util.HashMap;
import java.util.ArrayList;

public class Test{
	public static void main(String[]args){
		// Objets
	Activity options = new Activity ("Choisir mes options", 70);
	Activity ip = new Activity ("Inscription pédagogique", 30);
	PrecedenceConstraint contrainte = new PrecedenceConstraint (options, ip);
	int neufHeures = 9;
	int dixHeures = 10;
	int onzeHeures = 11;

	System.out.println("------------------------------------------------------------------");
	// Test avec une programmation censée satisfaire la contrainte
	if ( ! contrainte.isSatisfied(neufHeures, onzeHeures)) {
		System.out.println("Mon programme ne marche pas.");
		System.out.println("Il aurait du trouver que la contrainte nest satisfaite.");
	} else {
		System.out.println("Mon programme passe le premier test avec succes.");
	}

	// Test avec une programmation censée ne pas satisfaire la contrainte
	if (contrainte.isSatisfied(dixHeures, neufHeures)) {
		System.out.println("Mon programme ne marche pas.");
		System.out.println("Il aurait du trouver que la contrainte n'est pas satisfaite.");
	} else {
		System.out.println("Mon programme passe le deuxieme test avec succes.");
	}

	// Test avec une programmation censée ne pas satisfaire la contrainte (car la première
	// activité finirait après le début de la seconde)
	if ( contrainte.isSatisfied(neufHeures, dixHeures)) {
		System.out.println("Mon programme ne marche pas.");
		System.out.println("Il aurait dû trouver que la contrainte n'est pas satisfaite.");
	} else {
		System.out.println("Mon programme passe le troisieme test avec succes.");
	}

	HashMap<Activity, Integer> edt = new HashMap<> ();

	Activity activite1 = new Activity ("POO", 120);
	Activity activite2 = new Activity ("ALGO", 120);
	Activity activite3 = new Activity ("ANGLAIS", 60);
	Activity activite4 = new Activity ("TECH EXP", 60);

	PrecedenceConstraint c1 = new PrecedenceConstraint (activite1,activite2);
	PrecedenceConstraint c2 = new PrecedenceConstraint (activite2,activite3);
	PrecedenceConstraint c3 = new PrecedenceConstraint (activite1,activite4);


	edt.put(activite1, 8);
  edt.put(activite2, 10);
	edt.put(activite3, 12);
	edt.put(activite4, 12);

	System.out.println("premier emploi du temps :\n"+edt);

	System.out.println("L'emplois du temps satisfait-il c1 ? "+ c1.isSatisfiedBySchedule(edt));
	System.out.println("L'emplois du temps satisfait-il c2 ? "+ c2.isSatisfiedBySchedule(edt));
	System.out.println("L'emplois du temps satisfait-il c3 ? "+ c3.isSatisfiedBySchedule(edt));
 /* creation de verifier et insertions des contraintes */
	Verifier verifieur = new Verifier();

	// Contrainte : activité1 doit être planifiée avant activite2
	verifieur.add(new PrecedenceConstraint(activite1, activite2));

	// Contrainte : activité4 doit commencer précisément quand activité3 se termine
	verifieur.add(new MeetConstraint(activite3, activite4));

	// Contrainte : activité1, activité2 et activité3 doivent toutes
	// être exécutées en au plus 90 minutes
	ArrayList<Activity> ensemble = new ArrayList<> ();
	ensemble.add(activite1);
	ensemble.add(activite2);
	ensemble.add(activite3);


	HashMap<Activity, Integer> emploiDuTemps = new HashMap<Activity, Integer> ();
	emploiDuTemps.put(activite1,0);
	emploiDuTemps.put(activite2,20);
	emploiDuTemps.put(activite3,30);
	emploiDuTemps.put(activite4,31);
	System.out.println("------------------------------------------------------------------");

 	System.out.println("Second emploi du temps (celui qui satisferas notre max span) : \n"+emploiDuTemps);

	MaxSpanConstraint contrainteEnsemble = new MaxSpanConstraint(ensemble, 90);

	/*ajout de la contrainte maxspan contrainteEnsemble*/
	verifieur.add(contrainteEnsemble);

	System.out.println("-----------------------------------");
	System.out.println("Test du MaxSpan constraint :"+contrainteEnsemble.isSatisfiedBySchedule(emploiDuTemps));
	System.out.println("-----------------------------------");

	System.out.println("L'emploi du temps satisfait-il toutes les contraintes ? ");
	if (verifieur.verify(emploiDuTemps)) {
		System.out.println("Oui");
	} else {
		System.out.println("Non");
	}

	RandomScheduler ran = new RandomScheduler();
	ran.addActivity(activite1);
	ran.addActivity(activite2);
	ran.addActivity(activite3);
	ran.addActivity(activite4);

	ran.addConstraint(new PrecedenceConstraint(activite1, activite2));
	ran.addConstraint(new MeetConstraint(activite3, activite4));
	ran.addConstraint(contrainteEnsemble);
	System.out.println("----------------------------------------");
	HashMap<Activity, Integer> createdt=ran.createHashMap();
	System.out.println("\nAffichage de l'emplois du temps avec des heures random \n"+createdt);

	System.out.println("\nNombre de contraintes qu'il satisfaite est  :"+ran.nbConstraint(createdt));
  System.out.println("---------------------------------\nCreation des hashMap et affichage de celui qui satisfait le plus de contrainte :\n");

	HashMap<Activity, Integer>random=ran.scheduleGenerator(3);
	System.out.println(random);
	System.out.println("------------------------------------");
	System.out.println("Le nombre de contraintes qu'il satisfait est: "+ran.nbConstraint(random));




System.out.println("\n\n-----------------------------LES TESTS READER:---------------------------------\n");

	try{
			Reader R=new Reader("filrouge/activities.txt","filrouge/constraints.txt");
			System.out.println(R.getActivities());
			System.out.println("\n\n");
			String[] tab = {"cafe","bus"};
			System.out.println("\nTest de getprecedence entre prendre un café et un bus \n "+R.getPrecedenceConstraint(tab)+"\n\n");
			System.out.println("\nLa classe reader :\nAffichage des contraintes \n\n"+R.readConstraint()+"\n\n");
		}
		catch (java.io.FileNotFoundException e)
		{
			System.err.println("Une exception a ete lever fichier introuvable !!!!!!");
		}
		catch (java.io.IOException e)
		{
			System.err.println("Une exception d'entrée sortie a été lever ");
		}
		catch (java.lang.IllegalArgumentException e) {
			System.err.println(e.getMessage());
		}



	}

	}
