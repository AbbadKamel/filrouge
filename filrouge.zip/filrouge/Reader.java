package filrouge;
import java.util.*;
import scheduleio.ActivityReader;
import scheduleio.ActivityDescription;
import scheduleio.ConstraintDescription;
import scheduleio.ConstraintReader;

public class Reader{

	public Map<String ,Activity> list;
	public String file1,file2;

	//file1 is the activities and file2 is constraints
	public Reader(String file1, String file2)throws java.io.FileNotFoundException, java.io.IOException{
		this.file1=file1;
		this.file2 = file2;
		//create ActivityReader's instance
		ActivityReader reader = new ActivityReader(file1);
		Map<String ,ActivityDescription> mapfile =reader.readAll();
		list=new HashMap<String, Activity>();
		for(String cle : mapfile.keySet()){
			Activity act = new Activity(mapfile.get(cle).getName(),mapfile.get(cle).getDuration());
			list.put(cle,act);
		}

}


	public Collection<Activity> getActivities(){
		return this.list.values(); //return the activities
	}

	public PrecedenceConstraint getPrecedenceConstraint(String [] arguments) throws java.lang.IllegalArgumentException {
			if (arguments.length!=2) {
				throw new java.lang.IllegalArgumentException("EXCEPTION levé !!  non respecté ");
			}
			if (!list.containsKey(arguments[0]) || !list.containsKey(arguments[1])) {
				throw new java.lang.IllegalArgumentException("EXCEPTION levé !! id des arguments non contenue dans le Map1");
			}
			PrecedenceConstraint precon=new PrecedenceConstraint(list.get(arguments[0]),list.get(arguments[1]));
			return precon;
		}



		public PrecedenceConstraintWithGap getPrecedenceConstraintwithGap(String [] arguments) throws java.lang.IllegalArgumentException {
			if (arguments.length!=3) {
				throw new java.lang.IllegalArgumentException("EXCEPTION levé !!  non respecté ");
			}
			if (!list.containsKey(arguments[1]) || !list.containsKey(arguments[2])) {
				throw new java.lang.IllegalArgumentException("EXCEPTION levé !! id des arguments non contenue dans le Map2");
			}
			int gap = Integer.parseInt(arguments[0]);
			PrecedenceConstraintWithGap PreconGap = new PrecedenceConstraintWithGap(list.get(arguments[1]),list.get(arguments[2]),gap);
			return PreconGap;


		}



		public MeetConstraint getPrecedenceConstraintMeet(String [] arguments) throws java.lang.IllegalArgumentException {
			if (arguments.length!=2) {
				throw new java.lang.IllegalArgumentException("EXCEPTION !! taille pour les arguments de getPrecendenceConstraint non respecté ");
			}
			if (!list.containsKey(arguments[0]) || !list.containsKey(arguments[1])) {
				throw new java.lang.IllegalArgumentException("EXCEPTION levé !! id des arguments non contenue dans le Map3");
			}
			MeetConstraint preconmeet=new MeetConstraint(list.get(arguments[0]),list.get(arguments[1]));
			return preconmeet;
		}


		public MaxSpanConstraint getMaxSpanConstraint(String [] arguments) throws java.lang.IllegalArgumentException {
			if (arguments.length < 3) {
				throw new java.lang.IllegalArgumentException("EXCEPTION levé !!  non respecté");
			}
			if (!list.containsKey(arguments[1]) || !list.containsKey(arguments[2])) {
				throw new java.lang.IllegalArgumentException("EXCEPTION levé !! id des arguments non contenue dans le Map4");
			}
			int maxspan = Integer.parseInt(arguments[0]);
			ArrayList<Activity> activityArray = new ArrayList<Activity>();
			for (int i = 1; i < list.size(); i++) {
				Activity a = list.get(arguments[i]);
				activityArray.add(a);
			}
			 MaxSpanConstraint Maxpreco = new MaxSpanConstraint(activityArray,maxspan);
			 return Maxpreco;
		}




			public ArrayList<Constraint> readConstraint() throws java.io.FileNotFoundException, java.io.IOException{
			ConstraintReader descread=new ConstraintReader(this.file2);
			List<ConstraintDescription> f2 = descread.readAll();
			ArrayList<Constraint> constArray = new ArrayList<Constraint>();
			for (ConstraintDescription c : f2) {
				if (c.getKeyword().equals("PRECEDENCE")) {
					PrecedenceConstraint pc = this.getPrecedenceConstraint(c.getArguments());
					constArray.add(pc);
				}
				if (c.getKeyword().equals("PRECEDENCE_GAP")) {
					PrecedenceConstraintWithGap pc = this.getPrecedenceConstraintwithGap(c.getArguments());
					constArray.add(pc);
				}
				if (c.getKeyword().equals("MEET")) {
					MeetConstraint pc = this.getPrecedenceConstraintMeet(c.getArguments());
					constArray.add(pc);
				}
				if (c.getKeyword().equals("MAX_SPAN")) {
					MaxSpanConstraint pc = this.getMaxSpanConstraint(c.getArguments());
					constArray.add(pc);
				}
			}
			return constArray;
		}
}
