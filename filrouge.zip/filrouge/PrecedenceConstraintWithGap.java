package filrouge;
import java.util.HashMap;

public class PrecedenceConstraintWithGap extends PrecedenceConstraint{

    public int gap;//Une durée de plus(écart)

    public PrecedenceConstraintWithGap(Activity first, Activity second, int gap){
    //Constructeur qui initialise les attributs
        super(first,second);
        this.gap=gap;
    }

    public boolean isSatisfied(int date1, int date2){
    //Test si act2 commence après act1 avec une durée gap et deux dates
    		if((date1*60 + this.first.duree +gap) <= (date2*60)){
    		    return true;
	      } else{
    		    return false;
    		}
    }

        @Override
    public String toString(){//overriding the toString() method
        return "\n* "+this.first+"  commence avant  "+this.second+"  avec un gap(écart)  "+this.gap+" min ";
    }
}
