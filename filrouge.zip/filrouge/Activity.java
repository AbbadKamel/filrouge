package filrouge;

public class Activity{

		public String descrip; //Une description
		public int duree; //Une durée

		public Activity(String descrip, int duree){
			//Un constructeur pour initialiser les attributs de la classe
				this.descrip = descrip;
				this.duree = duree;
		}

		public String toString() {
			//Une méthode toString() qui retourne la déscription et la durée de l'activité
				return "l'activité : "+this.descrip+" d'une durée: " + this.duree+" min ";
		}
}
