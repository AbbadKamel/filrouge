package filrouge;
import java.util.ArrayList;
import java.util.HashMap;

public class Verifier{
		public  ArrayList<Constraint> list;//Attribut list

		public Verifier(){//Constructeur qui initialise la liste
			this.list = new ArrayList<Constraint>();
		}

		public void add(Constraint constraint){//Une méthode pour ajouter des contraintes
			this.list.add(constraint);
		}

		public boolean verify(HashMap<Activity, Integer> edt){
		//Une méthode qui retourne un boolean si toutes les contraintes sont vérifiées

		  for(int i=0;i<this.list.size();i++){
		  	//On parcours la liste pour tester
				if(!(this.list.get(i).isSatisfiedBySchedule(edt))){
					//Retourner false si une contrainte n'est pas satisfaite
					System.out.println(this.list.get(i));
					return false;

				}
		  }
					return true;//Retourner true si toutes les contraintes sont satisfaites
		}
}
