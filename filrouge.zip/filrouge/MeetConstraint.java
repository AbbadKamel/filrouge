package filrouge;

public class MeetConstraint extends BinaryConstraint implements Constraint{


		public MeetConstraint(Activity first,Activity second){
			super(first,second);
		}


		public boolean isSatisfied(int date1,int date2){
		//Test si act2 commence après act1 avec les deux dates
			int d1=date1*60+first.duree;
			int d2=date2*60;

			if(d1==d2){
						return true;
			}
			else{
				return false;
			}
		}

		public String toString(){
		return "\n* " +this.second+ " commence juste après  "+ this.first+" "; 
	}
}
